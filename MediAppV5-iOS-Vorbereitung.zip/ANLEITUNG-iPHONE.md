# MediAppV5 – Vorbereitung für iOS

## Inhalt

Dies ist ein **Quellcode-Projektpaket**, keine installierbare iPhone-App und keine signierte IPA. Die vorhandene Version 5 wurde in den Ordner `www/` übernommen. Die Capacitor-Konfiguration verwendet nun `webDir: www` statt `.`; dadurch wird nicht versehentlich das gesamte Projekt als Web-Inhalt eingebunden.

## Nächste Schritte nur mit iPhone

1. Lege auf GitHub ein **neues Repository** an (z. B. `MediApp-iOS`), damit die funktionierende Web-App unangetastet bleibt.
2. Lade den **entpackten Inhalt** dieses Pakets hoch. Achte darauf, dass `package.json`, `capacitor.config.json`, `www/` und `.github/` im Repository-Stamm liegen. GitHub unterstützt beim Upload auf dem iPhone gegebenenfalls nur einzelne Dateien; für komplette Ordner kann eine GitHub-kompatible Dateiverwaltung oder ein Git-Client nötig sein.
3. Öffne im Repository **Actions** und starte `iOS Build-Prüfung (Simulator, ohne Signierung)` über `Run workflow`. Der Workflow prüft auf einem Mac-Cloud-Runner, ob der iOS-Code kompiliert.
4. Ein erfolgreicher Simulator-Build ist **noch keine TestFlight-App**. Für die Installation auf deinem eigenen iPhone über TestFlight sind Apple Developer Program, App Store Connect, eine eindeutige Bundle-ID, Signierungszertifikate und ein signierter iOS-Build nötig. Ein separater Signierungs- und Upload-Workflow wird dafür eingerichtet.

## Vor TestFlight unbedingt prüfen

- Das Kapsel-Icon muss als **iOS-App-Icon im Xcode-Asset-Katalog** gesetzt werden; die PWA-Icons im Ordner `www/icons/` allein genügen dafür nicht.
- Die native Erinnerungsfunktion ist bisher nur für **tägliche** Einnahmepläne vorbereitet. Alle Erinnerungsarten, Berechtigungen und Hintergrundverhalten müssen auf einem echten iPhone getestet werden.
- Safari/PWA-Daten werden nicht automatisch in den nativen App-Speicher übernommen. **Vor dem Wechsel in der bisherigen App ein JSON-Backup exportieren** und später in der nativen App importieren.
- Medizinische Einnahmeerinnerungen sind kein Ersatz für ärztliche Anweisungen; die App darf keine Einnahme als bestätigt darstellen, solange sie nicht ausdrücklich protokolliert wurde.
- `de.mediapp.meinemedikamente` ist eine **vorläufige Bundle-ID** und muss vor Veröffentlichung auf eine dauerhaft eindeutige ID angepasst werden.
- Vor öffentlicher Veröffentlichung Datenschutzinformationen, App-Store-Angaben und tatsächliche Datenspeicherung prüfen.

## Technische Eckdaten

- Capacitor 7
- Lokale Web-Dateien: `www/`
- iOS-Build-Prüfung via GitHub Actions (`macos-latest`)
- Kein Apple-Developer-Konto für den **Quellcode und Simulator-Build-Check** nötig
